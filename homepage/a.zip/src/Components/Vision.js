import React, { Component } from "react";
import "./CSS/projectCards.css";

class Vision extends Component {
    render() {
        return (
            <div className="cards">
                <div className="item">
                    <p className="title">1 - improving image quality</p>
                    <p className="desc">
                        improving quiality of images using some methods like
                        histogram normalization
                    </p>
                    <img src={require("../Images/improve.jpg")} />
                </div>
                <div className="item">
                    <p className="title">2 - Texture Synthesizing</p>
                    <p className="desc">
                        trying to fill up empty space using patches from other
                        parts of image. using image pyramid to improve patch
                        finding process. without any manualy restrictions.
                    </p>
                    <img src={require("../Images/stich.jpg")} />
                </div>
                <div className="item">
                    <p className="title">3 - active contour</p>
                    <p className="desc">-</p>
                    <img src={require("../Images/movie01.gif")} />
                </div>
                <div className="item">
                    <p className="title">4 - morphing</p>
                    <p className="desc">
                        morphing images (requires user to input some points)
                    </p>
                    <img src={require("../Images/q2.gif")} />
                </div>
                <div className="item">
                    <p className="title">5 - poisson blending</p>
                    <p className="desc">
                        image alignation code has some bugs but with manually
                        setted cordinates other codes work fine
                    </p>
                    <img src={require("../Images/zLeo.jpg")} />
                </div>
            </div>
        );
    }
}

export default Vision;
